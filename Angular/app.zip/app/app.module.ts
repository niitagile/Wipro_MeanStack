import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GreetComponent } from './greet/greet.component';
import { RoundBlockDirective } from './round-block.directive';
import { PasswordlengthdetectorDirective } from './passwordlengthdetector.directive';
import { PowerPipe } from './power.pipe';
import { ReactiveformexampleComponent } from './reactiveformexample/reactiveformexample.component';
import { ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    GreetComponent,
    RoundBlockDirective,
    PasswordlengthdetectorDirective,
    PowerPipe,
    ReactiveformexampleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

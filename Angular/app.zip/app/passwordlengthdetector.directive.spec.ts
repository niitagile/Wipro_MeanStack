import { PasswordlengthdetectorDirective } from './passwordlengthdetector.directive';

describe('PasswordlengthdetectorDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordlengthdetectorDirective();
    expect(directive).toBeTruthy();
  });
});

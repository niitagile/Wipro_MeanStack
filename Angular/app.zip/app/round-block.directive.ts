import { Directive, ElementRef, Input, Renderer2,OnInit } from '@angular/core';

@Directive({
  selector: '[appRoundBlock]'
})
export class RoundBlockDirective implements OnInit{
  @Input() appRoundBlock : string="";
  constructor(private renderer: Renderer2, private elmref: ElementRef) { 
  }
ngOnInit(): void {
    let roundVal='${this.appRoundBlock}';
    this.renderer.setStyle(this.elmref.nativeElement, 'border-radius',roundVal);
}
}
